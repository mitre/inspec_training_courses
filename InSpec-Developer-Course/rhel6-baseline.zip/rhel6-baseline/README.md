# Example InSpec Profile

this example shows the implementation of an InSpec profile.
