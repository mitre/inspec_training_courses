control "V-38599" do
  title "The FTPS/FTP service on the system must be configured with the
Department of Defense (DoD) login banner."
  desc  "This setting will cause the system greeting banner to be used for FTP
connections as well."
  impact 0.5
  tag "gtitle": "SRG-OS-000023"
  tag "gid": "V-38599"
  tag "rid": "SV-50400r3_rule"
  tag "stig_id": "RHEL-06-000348"
  tag "fix_id": "F-43564r3_fix"
  tag "cci": ["CCI-000048"]
  tag "nist": ["AC-8 a", "Rev_4"]
  tag "false_negatives": nil
  tag "false_positives": nil
  tag "documentable": false
  tag "mitigations": nil
  tag "severity_override_guidance": false
  tag "potential_impacts": nil
  tag "third_party_tools": nil
  tag "mitigation_controls": nil
  tag "responsibility": nil
  tag "ia_controls": nil
  tag "check": "Verify the \"vsftpd\" package is installed:
# rpm -qa | grep -i vsftpd
vsftpd-3.0.2-22.e16.x86_64

If the \"vsftpd\" package is not installed, this is Not Applicable.

To verify this configuration, run the following command:

grep \"banner_file\" /etc/vsftpd/vsftpd.conf

The output should show the value of \"banner_file\" is set to \"/etc/issue\",
an example of which is shown below.

# grep \"banner_file\" /etc/vsftpd/vsftpd.conf
banner_file=/etc/issue

If it does not, this is a finding."
  tag "fix": "Edit the vsftpd configuration file, which resides at
\"/etc/vsftpd/vsftpd.conf\" by default. Add or correct the following
configuration options.

banner_file=/etc/issue

Restart the vsftpd daemon.

# service vsftpd restart"
end

